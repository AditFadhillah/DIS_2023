import psycopg2
import pandas as pd
from config import *


class SQLSetup:
    host = DB_HOST
    user = DB_USER
    password = DB_PASSWORD
    database = DB_DATABASE

    def create_playlist_database(self):
        conn = psycopg2.connect(
            host=self.host,
            user=self.user,
            password=self.password
        )
        conn.autocommit = True  # Set autocommit to True
        c = conn.cursor()
        try:
            c.execute("CREATE DATABASE playlistdatabase")
        except psycopg2.errors.DuplicateDatabase:
            # Handle the case where the database already exists
            print("Database already exists")
        c.close()
        conn.close()


    def create_all_tables(self):
        conn = psycopg2.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database
        )
        self.create_song_table(conn)
        self.create_user_table(conn)
        self.create_playlist_table(conn)
        self.create_public_playlist_table(conn)
        self.create_private_playlist_table(conn)
        self.create_rate_table(conn)
        self.create_contains_table(conn)
        self.create_share_table(conn)
        self.create_user_genre_table(conn)
        conn.close()

    def create_song_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Song" (
                    songID INTEGER, 
                    name VARCHAR(255), 
                    duration VARCHAR(255), 
                    artist VARCHAR(255),
                    genre VARCHAR(255)
        )""")
        c.close()

    def create_user_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "User" (
                        username VARCHAR(255) PRIMARY KEY
        )""")
        c.close()

    def create_playlist_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Playlist" (
                        name VARCHAR(255),
                        username VARCHAR(255),
                        date VARCHAR(255),
                        PRIMARY KEY(name, username),
                        FOREIGN KEY (username) REFERENCES "User" (username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_public_playlist_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Public" (
                        name VARCHAR(255),
                        username VARCHAR(255),
                        PRIMARY KEY(name, username),
                        FOREIGN KEY (username, name) REFERENCES "Playlist" (username, name)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_private_playlist_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Private" (
                        name VARCHAR(255),
                        username VARCHAR(255),
                        password VARCHAR(255),
                        PRIMARY KEY(name, username),
                        FOREIGN KEY (username, name) REFERENCES "Playlist" (username, name)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_rate_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Rate" (
                        username VARCHAR(255),
                        songID INTEGER,
                        Rating BOOLEAN, 
                        PRIMARY KEY (username, songID),
                        FOREIGN KEY (username) REFERENCES "User" (username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE,
                        FOREIGN KEY (songID) REFERENCES "Song" (songID)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_contains_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Contains" ( 
                        name VARCHAR(255), 
                        username VARCHAR(255),
                        songID INTEGER,
                        PRIMARY KEY (name, username, songID),
                        FOREIGN KEY (songID) REFERENCES "Song" (songID)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE,
                        FOREIGN KEY (name, username) REFERENCES "Playlist" (name, username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_share_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "Share" (
                        username VARCHAR(255), 
                        name VARCHAR(255), 
                        superUsername VARCHAR(255),
                        rating BOOLEAN,
                        comment VARCHAR(255), 
                        PRIMARY KEY (username, name, superUsername),
                        FOREIGN KEY (username) REFERENCES "User" (username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE,
                        FOREIGN KEY (name, username) REFERENCES "Playlist" (name, username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE,
                        FOREIGN KEY (superUsername) REFERENCES "User" (username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def create_user_genre_table(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "UserGenre" (
                        username VARCHAR(255), 
                        genre VARCHAR(255), 
                        PRIMARY KEY (username, genre),
                        FOREIGN KEY (username) REFERENCES "User" (username)
                            ON DELETE CASCADE 
                            ON UPDATE CASCADE
        )""")
        c.close()

    def import_songs(self):
        conn = psycopg2.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database
        )
        df = pd.read_csv('data/billboard.csv')
        for _, row in df.iterrows():
            songID = row['SongID']
            genre = row['Genre']
            duration = row['Duration']
            name = row['Name']
            artist = row['Artist']
            c = conn.cursor()
            # Check if the record already exists
            c.execute("SELECT COUNT(*) FROM Song WHERE songID = %s", (songID,))
            count = c.fetchone()[0]
            if count > 0:
                # Update the existing record
                sql = "UPDATE Song SET name = %s, duration = %s, artist = %s, genre = %s WHERE songID = %s"
                c.execute(sql, (name, duration, artist, genre, songID))
            else:
                # Insert a new record
                sql = "INSERT INTO Song(songID, name, duration, artist, genre) VALUES (%s, %s, %s, %s, %s)"
                c.execute(sql, (songID, name, duration, artist, genre))
            conn.commit()
            c.close()
        conn.close()

    def sql_trigger(self):
        conn = psycopg2.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database
        )
        self.create_user_audit(conn)
        self.before_user_insert_trigger(conn)
        self.before_user_update_trigger(conn)
        self.before_user_delete_trigger(conn)
        conn.close()

    def create_user_audit(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS "user_audit" (
                            id SERIAL PRIMARY KEY,
                            username VARCHAR(255),
                            newUsername VARCHAR(255),
                            changeDate TIMESTAMP,
                            action VARCHAR(50)
        )""")
        c.close()

    def before_user_insert_trigger(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TRIGGER "before_user_create"
                        BEFORE INSERT ON "User"
                        FOR EACH ROW
                        INSERT INTO user_audit
                            SET action = 'insert',
                                username = NEW.username,
                                changeDate = NOW()
        """)
        c.close()

    def before_user_update_trigger(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TRIGGER before_user_update
                        BEFORE UPDATE ON "User"
                        FOR EACH ROW
                        INSERT INTO "user_audit"
                            SET action = 'update',
                                username = OLD.username,
                                newUsername = NEW.username,
                                changeDate = NOW()
                """)
        c.close()

    def before_user_delete_trigger(self, conn):
        c = conn.cursor()
        c.execute("""CREATE TRIGGER before_user_delete
                        BEFORE DELETE ON "User"
                        FOR EACH ROW
                        INSERT INTO "user_audit"
                            SET action = 'delete',
                                username = OLD.username,
                                changeDate = NOW()
                """)
        c.close()


sqlSetup = SQLSetup()
sqlSetup.create_playlist_database()
sqlSetup.create_all_tables()
sqlSetup.import_songs()
sqlSetup.sql_trigger()
