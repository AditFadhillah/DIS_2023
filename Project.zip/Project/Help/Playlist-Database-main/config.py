DB_HOST = 'localhost'
DB_USER = 'postgres'
DB_PASSWORD = '222121'
DB_DATABASE = 'postgres'
