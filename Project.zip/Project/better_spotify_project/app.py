import os
import psycopg2
from flask import Flask, render_template, request, url_for, redirect

app = Flask(__name__)

def get_db_connection():
    conn = psycopg2.connect(host='localhost',
                            database='SpotifyProject',
                            user=os.environ['DB_USERNAME'],
                            password=os.environ['DB_PASSWORD'])
    return conn


@app.route('/index/')
def index():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM MusicThrouple;')
    music = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('index.html', music=music)

@app.route('/', methods=('GET', 'POST'))
def home():
    if request.method == 'POST':
        song = request.form['song']
        album = request.form['album']
        artists = request.form['artists']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO MusicThrouple (throuple_artists, throuple_album, throuple_name, track_number, release_date)'
                    'VALUES (%s, %s, %s, %s, %s)',
                    (song, album, artists,None,None))
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for('index'))
    return render_template('home.html')