import psycopg2
import os
import pandas as pd
import numpy as np
from psycopg2.extensions import register_adapter, AsIs
register_adapter(np.int64, AsIs)

DATASET_PATH = os.path.join('dataset', 'tracks_test.csv') 
df = pd.read_csv(DATASET_PATH, sep=';')

conn = psycopg2.connect(
    host="localhost",
    database="SpotifyProject",
    user=os.environ['DB_USERNAME'],
    password=os.environ['DB_PASSWORD'])

with conn.cursor() as cur:
    # Run schema.sql
    with open('schema.sql') as db_file:
        cur.execute(db_file.read())
        print("opened schema.sql")

        # Import all data from the tracks_features dataset, song 
    all_songs = list(
        map(lambda x: tuple(x),
            df[['id', 'name', 'track_number', 'release_date']].to_records(index=False))
            )
    # Import all data from the tracks_features dataset, artist
    all_artists = list(set(
        map(lambda x: tuple(x),
            # df[['id', 'name', 'album', 'album_id', 'artists', 'artist_ids', 'track_number', 'disc_number', 'explicit', 'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness', 'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo', 'duration_ms', 'time_signature', 'year', 'release_date']].to_records(index=False))
            df[['artist_ids', 'artists']].to_records(index=False)))
    )

    all_albums= list(set(
        map(lambda x: tuple(x),
            # df[['id', 'name', 'album', 'album_id', 'artists', 'artist_ids', 'track_number', 'disc_number', 'explicit', 'danceability', 'energy', 'key', 'loudness', 'mode', 'speechiness', 'acousticness', 'instrumentalness', 'liveness', 'valence', 'tempo', 'duration_ms', 'time_signature', 'year', 'release_date']].to_records(index=False))
            df[['album_id', 'album']].to_records(index=False)))
    )

    all_throuples= list(set(
        map(lambda x: tuple(x),
            df[['artists', 'album', 'name', 'track_number', 'release_date']].to_records(index=False)))
    )


    args_str = ','.join(cur.mogrify("(%s, %s, %s, %s)", i).decode('utf-8') for i in all_songs)
    cur.execute("INSERT INTO Song (song_ID, song_name, track_num, release_date) VALUES " + args_str)

    args_str1 = ','.join(cur.mogrify("(%s, %s)", i).decode('utf-8') for i in all_artists)
    cur.execute("INSERT INTO Artist (art_ID, art_name) VALUES " + args_str1)

    args_str2 = ','.join(cur.mogrify("(%s, %s)", i).decode('utf-8') for i in all_albums)
    cur.execute("INSERT INTO Album (alb_ID, alb_name) VALUES " + args_str2)

    args_str3 = ','.join(cur.mogrify("(%s, %s, %s, %s, %s)", i).decode('utf-8') for i in all_throuples)
    cur.execute("INSERT INTO MusicThrouple (throuple_artists, throuple_album, throuple_name, track_number, release_date) VALUES " + args_str3)

    conn.commit()
    cur.close()        
    conn.close()