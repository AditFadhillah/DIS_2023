## Song database
A database that holds some pre-loaded songs. 
User can add new songs in the database.

# How to run.
1. Create Server at port 5432, name it SpotifyProject

2. Create database with the following attributes:
    name = SpotifyProject

    host = localhost

    port = 5432

    username = postgres

    password = DB_PASSWORD

3. Open a SpotifyProject=# in terminal and write:
    GRANT ALL PRIVILEGES ON DATABASE SpotifyProject TO postgres;

4. Be in folder of project and then write:
    . .venv/bin/activate

    export FLASK_APP=app
    
    export FLASK_ENV=development

    export DB_USERNAME="postgres"

    export DB_PASSWORD="DB_PASSWORD"
    
    flask run
